ic.error<-function(x, phy, error, tol=1e-8)
{
	ic<-pic(x, phy)
	b2<-mean(ic^2)
	b1<-0
	phy<-new2old.phylo(phy)
	tips<-phy$edge[,2]>0
	while(abs(b2-b1)>tol) {
		phy2<-phy
		phy2$edge.length[tips]<-phy$edge.length[tips]+error[phy$tip.label]/b2
		b1<-b2
		phy2<-old2new.phylo(phy2)
		ic<-pic(x, phy2)
		b2<-mean(ic^2)
		}
	return(list(ic=pic(x, phy2, scaled=T), phye=phy2))	
}
	